package bolt.lang;


import java.math.BigInteger;
import java.util.Random;

import org.springframework.stereotype.Component;
@Component
public class IDGenerator {

	public String  randomId() {
		return String.valueOf(new Random().nextInt(Integer.MAX_VALUE ));
	}
	
	public static void main(String args[]) {
		System.out.println(new IDGenerator().randomId());
	}
//1612313063
	//1299544953
}
