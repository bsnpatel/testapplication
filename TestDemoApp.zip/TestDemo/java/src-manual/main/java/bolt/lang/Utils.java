package bolt.lang;


import org.springframework.stereotype.Component;
@Component
public class Utils {

	public Boolean  isNullOrEmpty(Object o) {
		if (o==null) return true;
		
		if(o instanceof String) {
			return ((String) o).trim().length()==0;
		}
		return o!=null;
	}
	

}
