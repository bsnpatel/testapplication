package bolt.lang;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;
@SessionScope
@Component
public class InMemoryDatabase {

	static HashMap<String,List<Object>> map=new HashMap<String,List<Object>>();

	public <T> List<?> getAll(Class t) {
		System.out.println(t.getName());
		System.out.println("map.get(type)"+ map.get(t.getName()));
		List<?> list=map.get(t.getName());
		return list ==null ? new ArrayList<T>() : list;
	}
	
	public <T> void save(T object) {
		System.out.println("object.getClass().getName()"+ object.getClass().getName());
		List<Object> list=map.get(object.getClass().getName());
		if(list==null) {
			list=new ArrayList<Object>();
		}
		list.add(object);
		
		map.put(object.getClass().getName(),list);
	}

}
