package core.parameters;
import java.sql.Date;
import java.sql.Timestamp;
import java.math.BigInteger;
import java.math.BigDecimal;
import java.util.List;
import com.google.common.collect.Lists;

import core.ClaimLine;
public class ClaimLineServiceParam {
	
	boolean isDirty;	
	
	ClaimLine changes;
	public ClaimLineServiceParam() {
	}
	public ClaimLine getChanges() {
		return this.changes;
	}
	
	public void setChanges(ClaimLine changes) {
		this.changes=changes;
	}
	
}
