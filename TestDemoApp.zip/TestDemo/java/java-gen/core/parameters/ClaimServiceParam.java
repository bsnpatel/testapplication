package core.parameters;
import java.sql.Date;
import java.sql.Timestamp;
import java.math.BigInteger;
import java.math.BigDecimal;
import java.util.List;
import com.google.common.collect.Lists;

import core.Claim;
public class ClaimServiceParam {
	
	boolean isDirty;	
	
	Claim changes;
	public ClaimServiceParam() {
	}
	public Claim getChanges() {
		return this.changes;
	}
	
	public void setChanges(Claim changes) {
		this.changes=changes;
	}
	
}
