package core;
import java.sql.Date;
import java.sql.Timestamp;
import java.math.BigInteger;
import java.math.BigDecimal;
import java.util.List;
import com.google.common.collect.Lists;

import io.jsondb.annotation.Document;
import io.jsondb.annotation.Id;
@Document(collection = "ClaimLine", schemaVersion = "1.0")
public class ClaimLine {
	
	boolean isDirty;	
	
	String revenueCd;
	String modifierCd1;
	String modifierCd2;
	String modifierCd3;
	String modifierCd4;
	String lineCharge;
	String procedureCd;
	String diagPointer;
	Integer lineNo;
	@Id
	String id;
	Integer units;
	String placeOfService;
	public ClaimLine() {
		this.revenueCd = "";
		this.modifierCd1 = "";
		this.modifierCd2 = "";
		this.modifierCd3 = "";
		this.modifierCd4 = "";
		this.lineCharge = "";
		this.procedureCd = "";
		this.diagPointer = "";
		this.lineNo = 0;
		this.id = "";
		this.units = 0;
		this.placeOfService =  "";
	}
	public String getRevenueCd() {
		return this.revenueCd;
	}
					
	public void setRevenueCd(String revenueCd) {
		this.revenueCd=revenueCd;
	}
	public String getModifierCd1() {
		return this.modifierCd1;
	}
					
	public void setModifierCd1(String modifierCd1) {
		this.modifierCd1=modifierCd1;
	}
	public String getModifierCd2() {
		return this.modifierCd2;
	}
					
	public void setModifierCd2(String modifierCd2) {
		this.modifierCd2=modifierCd2;
	}
	public String getModifierCd3() {
		return this.modifierCd3;
	}
					
	public void setModifierCd3(String modifierCd3) {
		this.modifierCd3=modifierCd3;
	}
	public String getModifierCd4() {
		return this.modifierCd4;
	}
					
	public void setModifierCd4(String modifierCd4) {
		this.modifierCd4=modifierCd4;
	}
	public String getLineCharge() {
		return this.lineCharge;
	}
					
	public void setLineCharge(String lineCharge) {
		this.lineCharge=lineCharge;
	}
	public String getProcedureCd() {
		return this.procedureCd;
	}
					
	public void setProcedureCd(String procedureCd) {
		this.procedureCd=procedureCd;
	}
	public String getDiagPointer() {
		return this.diagPointer;
	}
					
	public void setDiagPointer(String diagPointer) {
		this.diagPointer=diagPointer;
	}
	public Integer getLineNo() {
		return this.lineNo;
	}
					
	public void setLineNo(Integer lineNo) {
		this.lineNo=lineNo;
	}
	public String getId() {
		return this.id;
	}
					
	public void setId(String id) {
		this.id=id;
	}
	public Integer getUnits() {
		return this.units;
	}
					
	public void setUnits(Integer units) {
		this.units=units;
	}
	public String getPlaceOfService() {
		return this.placeOfService;
	}
	
	public void setPlaceOfService(String placeOfService) {
		this.placeOfService=placeOfService;
	}
	
}
