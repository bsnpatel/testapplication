package core.services;


import java.util.List;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import java.math.BigInteger;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import org.springframework.web.bind.annotation.CrossOrigin;

import javax.servlet.http.HttpServletRequest;
				
import core.*;

import bolt.lang.TypeConverter;
import bolt.lang.IDGenerator;
import bolt.lang.Utils;
import superbolt.util.dao.DataManager;
				



@CrossOrigin
@RestController
public class ClaimLineService {
	
	@Autowired
			TypeConverter typeConverter;
	@Autowired
			IDGenerator idGenerator;
	@Autowired
			Utils utils;
	@Autowired
		
			DataManager<ClaimLine> dataManager;
	@RequestMapping(value = "/api/claimLine/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public core.ClaimLine findClaimLineById(@PathVariable("id") String id ){
	
			String findByid = "";
			findByid = id;	
			return this.dataManager.findById(findByid, "core", "ClaimLine") ;	
			}
	@RequestMapping(value = "/api/claimLine", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<core.ClaimLine> findAllClaimLine( ){
	
			return this.dataManager.findAll("core", "ClaimLine") ;	
			}
	@RequestMapping(value = "/api/claimLine/{id}", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public core.ClaimLine deleteClaimLine(@PathVariable("id") String id ){
	
			String findByid = "";
			findByid = id;	
			return this.dataManager.delete(findByid, "core", "ClaimLine") ;	
			}
	@RequestMapping(value = "/api/claimLine", method = RequestMethod.PUT, headers = "Accept=application/json")
	public core.ClaimLine saveClaimLine(@RequestBody core.parameters.ClaimLineServiceParam claimLineServiceParam ){
	
			if (this.utils.isNullOrEmpty(claimLineServiceParam.getChanges().getId()))
				{
					claimLineServiceParam.getChanges().setId(this.idGenerator.randomId());
					this.dataManager.save(claimLineServiceParam.getChanges());
					}
			return claimLineServiceParam.getChanges() ;	
			}
}
