package core.services;


import java.util.List;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import java.math.BigInteger;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import org.springframework.web.bind.annotation.CrossOrigin;

import javax.servlet.http.HttpServletRequest;
				
import core.*;

import bolt.lang.TypeConverter;
import bolt.lang.IDGenerator;
import bolt.lang.Utils;
import superbolt.util.dao.DataManager;
				



@CrossOrigin
@RestController
public class ClaimService {
	
	@Autowired
			TypeConverter typeConverter;
	@Autowired
			IDGenerator idGenerator;
	@Autowired
			Utils utils;
	@Autowired
		
			DataManager<Claim> dataManager;
	@RequestMapping(value = "/api/claim/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public core.Claim findClaimById(@PathVariable("id") String id ){
	
			String findByid = "";
			findByid = id;	
			return this.dataManager.findById(findByid, "core", "Claim") ;	
			}
	@RequestMapping(value = "/api/claim", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<core.Claim> findAllClaim( ){
	
			return this.dataManager.findAll("core", "Claim") ;	
			}
	@RequestMapping(value = "/api/claim/{id}", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public core.Claim deleteClaim(@PathVariable("id") String id ){
	
			String findByid = "";
			findByid = id;	
			return this.dataManager.delete(findByid, "core", "Claim") ;	
			}
	@RequestMapping(value = "/api/claim", method = RequestMethod.PUT, headers = "Accept=application/json")
	public core.Claim saveClaim(@RequestBody core.parameters.ClaimServiceParam claimServiceParam ){
	
			if (this.utils.isNullOrEmpty(claimServiceParam.getChanges().getId()))
				{
					claimServiceParam.getChanges().setId(this.idGenerator.randomId());
					this.dataManager.save(claimServiceParam.getChanges());
					}
			return claimServiceParam.getChanges() ;	
			}
}
