export const environment = {
  production: false,
  envName: 'local',
  apiEndpoint: 'https://localhost:8000',
  brokerURL: 'wss://localhost:8000/websocket'
};
