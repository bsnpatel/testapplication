export const environment = {
  production: false,
  envName: 'local',
  apiEndpoint: 'http://localhost:5200',
  brokerURL: 'wss://localhost:8000/websocket'
};
