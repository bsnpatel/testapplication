chrome.browserAction.onClicked.addListener(function(tab) {  
  chrome.windows.create({
    url: chrome.runtime.getURL("index.html"),
    type: "popup"
  }, function(win) {
    console.log("Window Opened",win,tab);
  });
});



chrome.storage.onChanged.addListener(function(changes){
  chrome.storage.local.get(['projectId','workFlowName','recording','pageVerification'], function(data) {
      if(data.recording)chrome.browserAction.setIcon({path: 'plugin/icons/icon16-rec.png'});
      else chrome.browserAction.setIcon({path: 'plugin/icons/icon16.png'});
  });
});

