var elements = [];
var elementsPath = [];
var tags = ["input", "select", "button", "a", "img", "mat-select", "mat-option"];
var events = ["click", "change"];
var actions = [];
var dom_observer = new MutationObserver(function (mutation) {
    loadElements();
    listenURLChange();
});

var config = {
    attributes: true,
    childList: true,
    subtree: true,
    characterData: true
};
const onLoad = function () {
    localStorage.setItem("url", window.location.href);
    if (localStorage.getItem("recording") != null && localStorage.getItem("recording") == "true") {
        dom_observer.observe(document.body, config);
        events.forEach(event => {
            document.body.addEventListener(event, captureEvent, true);
        });
        loadElements();

    }
    if (localStorage.getItem("pageVerification") != null && localStorage.getItem("pageVerification") == "true") {
        dom_observer.observe(document.body, config);
        /* events.forEach(event=>{
            document.body.addEventListener(event, captureEvent, true);
        }); */
        loadElements();
        verifyElements();
    }


}

const captureVariable = function (event) {
    if (event.button === 2) {
        if (typeof window.getSelection != "undefined" && window.getSelection().type == "Range") {
            var el = getActualElement(event.srcElement);
            var json = getVariable(el);
            if (json != "") {
                event.preventDefault();
                openModal(json);
            }
        }
    }
}

const openModal = function (selectedText) {
    var obj = JSON.parse(selectedText);
    var variableText = obj.VariableName.text;
    var variableXpath = obj.VariableName.xpath.replace(/'/g, '&quot;');
    var modals = document.createElement("div");
    modals.innerHTML = "<div id='saveVariableModal' style='position:fixed;z-index:1;padding-top:100px;left:0;top:0;width:100%;height:100%;overflow:auto;background-color:rgb(0,0,0);background-color: rgba(0,0,0,0.4);'><div class='modal-content' style='background-color: #fefefe;  margin: auto;  padding: 20px;  border: 1px solid #888;  width: 80%;'><span class='close' id='closeModalPopup' onmouseover='function mouseOver(){var closerX=document.getElementById(&#39;closeModalPopup&#39;);closerX.style.color =&#39;#000&#39;;closerX.style.cursor=&#39;pointer&#39;;} mouseOver()' onclick='function closeModal(){var modalToRemove = document.getElementById(&#39;saveVariableModal&#39;);modalToRemove.remove();} closeModal()' style='color: #aaaaaa;  float: right;  font-size: 28px;  font-weight: bold;'>&times;</span><div align='center'><h2>Save Flow Variable</h2><table><tr><th align='right'>Name</th><td><input id='variableName' type='text' placeholder='Enter a name for the Variable' style='width:100%'></td></tr><tr><th align='right'>Text</th><td><textarea rows='4' cols='50' id='textInput' disabled style='resize:none;width:100%;'>" + variableText + "</textarea></td></tr><th align='right'>Xpath</th><td><textarea style='resize:none;width:100%;' rows='4' cols='50' id='xpathInput' onchange='function getModifiedXpath(){var oldxpath = document.getElementById(&#39;xpathInput&#39;);var oldtext = document.getElementById(&#39;textInput&#39;);var nodesSnapshot = document.evaluate(oldxpath.value, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);if(nodesSnapshot.singleNodeValue == null){oldtext.innerHTML = &#39;Undefined Element Change the Xpath&#39;;}else{oldtext.innerHTML = nodesSnapshot.singleNodeValue.innerHTML.trim();}} getModifiedXpath()'>" + variableXpath + "</textarea></td></tr><tr><td></td><td></td></tr><tr><td></td><td><input type='button' id='closeVariableModal' value='Close' onclick='function closeModal(){var modalToRemove2 = document.getElementById(&#39;saveVariableModal&#39;);modalToRemove2.remove();}closeModal()' style='width:50%' ><input type='button' id='submitVariable' value='Save Variable' style='width:50%' onclick='function saveVariableValue(){var varText = document.getElementById(&#39;textInput&#39;).value;varXpath = document.getElementById(&#39;xpathInput&#39;).value;varName = document.getElementById(&#39;variableName&#39;).value;var json = {&#39;Variable&#39;:{&#39;name&#39;:varName,&#39;text&#39;:varText, &#39;xpath&#39;:varXpath}};var variableJSON = JSON.stringify(json, null, 2); var closeModalFlag = false;if((varName == &#39;&#39; || varName == null) || (varText == &#39;&#39; || varText == null) || (varXpath == &#39;&#39; || varXpath == null)){alert(&#39;All 3 files - Name, Text and Xpath are Mandatory!&#39;);}else{var elements1 = localStorage.getItem(&#39;elements&#39;);elements1 = elements1.substring(0, elements1.length - 1);var models1 = localStorage.getItem(&#39;actions&#39;);var models = JSON.parse(localStorage.getItem(&#39;actions&#39;));models1 = models1.substring(0, models1.length - 1); var model = models[0].element.boltPageModel; var sequence = models[0].boltTestSequence; var pageModel = models[0].pageModel;var data = &#39;,{&#34;type&#34;:&#34;save&#34;,&#34;actionType&#34;:&#34;save&#34;,&#34;actionElementType&#34;:&#34;variable&#34;,&#34;elementId&#34;:&#34;&#39;+varName+&#39;&#34;,&#34;elementName&#34;:&#34;&#39;+varName+&#39;&#34;,&#34;element&#34;:{&#34;id&#34;:&#34;&#39;+varName+&#39;&#34;,&#34;name&#34;:&#34;&#39;+varName+&#39;&#34;,&#34;type&#34;:&#34;variable&#34;,&#34;tag&#34;:&#34;&#34;,&#34;title&#34;:&#34;&#34;,&#34;path&#34;:&#34;&#34;,&#34;xpath&#34;:&#34;&#39;+varXpath+&#39;&#34;,&#34;boltPageModel&#34;:&#34;&#39;+model+&#39;&#34;,&#34;innerText&#34;:&#34;&#39;+varText+&#39;&#34;,&#34;className&#34;:&#34;&#34;},&#34;flowVariableSet&#34;:&#34;VariableSet1&#34;,&#34;flowVariable&#34;:&#34;&#39;+varName+&#39;&#34;,&#34;value&#34;:&#34;&#39;+varText+&#39;&#34;,&#34;boltTestSequence&#34;:&#34;&#39;+sequence+&#39;&#34;,&#34;pageModel&#34;:&#34;&#39;+pageModel+&#39;&#34;,&#34;elementModel&#34;:&#34;&#39;+varXpath+&#39;&#34;}&#39; ; var elementData = &#39;{&#34;id&#34;:&#34;&#39;+varName+&#39;&#34;,&#34;name&#34;:&#34;&#39;+varName+&#39;&#34;,&#34;type&#34;:&#34;variable&#34;,&#34;tag&#34;:&#34;&#34;,&#34;title&#34;:&#34;&#34;,&#34;path&#34;:&#34;&#34;,&#34;xpath&#34;:&#34;&#39;+varXpath+&#39;&#34;,&#34;boltPageModel&#34;:&#34;&#39;+model+&#39;&#34;,&#34;innerText&#34;:&#34;&#39;+varText+&#39;&#34;,&#34;className&#34;:&#34;&#34;}&#39; ;models1 = models1 + data + &#39;]&#39; ;elements1 = elements1 + elementData + &#39;]&#39;; var saver = localStorage.getItem(&#39;variableElement&#39;);if(saver == null) {localStorage.setItem(&#39;variableElement&#39;,elementData);} else {localStorage.setItem(&#39;variableElement&#39;,saver + &#39;,&#39; + elementData); } localStorage.setItem(&#39;actions&#39;,models1); var saverData = localStorage.getItem(&#39;saveData&#39;);if(saverData == null) {localStorage.setItem(&#39;saveData&#39;,data);} else {localStorage.setItem(&#39;saveData&#39;,saverData + data); }  closeModalFlag=true;} if(closeModalFlag){var modalToRemove2 = document.getElementById(&#39;saveVariableModal&#39;);modalToRemove2.remove();}} saveVariableValue()'></td></tr></table></div></div></div>";
    document.body.appendChild(modals);

}

const verifyElements = function () {
    var elementsToVerify = [];
    chrome.storage.local.get(['pageVerification', 'elementsToVerify'], function (data) {
        elementsToVerify = JSON.parse(data.elementsToVerify)


        for (var i = 0; i < elementsToVerify.length; i++) {
            var element = elementsToVerify[i]
            if (e.xpath) {
                var matchingElement = elements.filter(e =>
                    (e.xpath) === element.xpath
                )
                //        elementsToVerify[i].verified=matchingElement.length>0? true : false
                //
                elementsToVerify[i].verificationResults = []
                elementsToVerify[i].verified = false;
                if (matchingElement.length > 0) {
                    elementsToVerify[i].elementFound = true;
                    elementsToVerify[i].verified = true;
                    var matchedElement = matchingElement[0]

                    // Rule 1
                    if (element.type.toLowerCase() !== matchedElement.type.toLowerCase()) {
                        elementsToVerify[i].verified = false;
                        elementsToVerify[i].verificationResults.push("Type Mismatch")
                    }

                    // Rule 2 - Match Links
                    if (element.link && matchedElement.link && element.link.toLowerCase() !== matchedElement.link.toLowerCase()) {
                        elementsToVerify[i].verified = false;
                        elementsToVerify[i].verificationResults.push("Link Mismatch")
                    }

                    // Rule 3 - Match Text
                    if (element.text && matchedElement.text && element.text !== matchedElement.text) {
                        elementsToVerify[i].verified = false;
                        // Rule 3.1 - Match Text
                        if (element.text && matchedElement.text && element.text.toLowerCase() !== matchedElement.text.toLowerCase()) {
                            elementsToVerify[i].verified = false;
                            elementsToVerify[i].verificationResults.push("Text Mismatch")
                        } else {
                            elementsToVerify[i].verificationResults.push("Text Case Mismatch")
                        }
                    }

                    // Rule 4 - Match Length 
                    if (element.maxLength && element.maxLength !== matchedElement.maxLength) {
                        elementsToVerify[i].verified = false;
                        elementsToVerify[i].verificationResults.push("Max Length Mismatch")
                    }

                    // Rule 5 - Match Label 
                    if (element.label && matchedElement.label && element.label !== matchedElement.label) {
                        elementsToVerify[i].verified = false;
                        // Rule 5.1 - Match Text
                        if (element.label && matchedElement.label && element.label.toLowerCase() !== matchedElement.label.toLowerCase()) {
                            elementsToVerify[i].verified = false;
                            elementsToVerify[i].verificationResults.push("Label Mismatch")
                        } else {
                            elementsToVerify[i].verificationResults.push("Label Case Mismatch")
                        }
                    }


                    // Add more Rules

                } else {
                    elementsToVerify[i].elementFound = false;
                }

            }

        }

        var elementDetails = { 'elementsToVerify': JSON.stringify(elementsToVerify) };
        chrome.storage.local.set(elementDetails, function () {
            console.log("elements set to " + JSON.stringify(elementsToVerify))
        });
    });

}
const loadElements = function () {
    for (var tag in tags) {
        var elementsArray = document.body.getElementsByTagName(tags[tag]);
        for (var i = 0; i < elementsArray.length; i++) {
            var el = getElement(elementsArray[i]);
            if (el.id == "variableName" || el.id == "closeVariableModal" || el.id == "submitVariable") continue;
            if (el.type == "hidden") continue;
            if (filterElement(el) && elementsPath.indexOf(el.path) < 0) {
                elements.push(el);
                elementsPath.push(el.path);
            }
        }
    }
    /*var variableElement = JSON.parse(localStorage.getItem("variableElement"));
    console.log(variableElement);
    if(variableElement != null){
        elements.push(variableElement);
    }
    elements = this.elements.filter((obj, pos, arr) => {
            return arr.map(mapObj =>
                  mapObj.name).indexOf(obj.name) == pos;
            });*/
    localStorage.setItem("elements", JSON.stringify(elements));
    if (localStorage.getItem("pageVerification") == "true") {
        var elementDetails = { 'elements': JSON.stringify(elements) };
        chrome.storage.local.set(elementDetails, function () {
            console.log("elements set to " + JSON.stringify(elements))
        });
    }
}

const filterElement = function (element) {
    var pluginElements = [];
    if (pluginElements.indexOf(element.id) > -1 || element.className.indexOf("superbolt") > -1) return false;
    else return true;
}


const captureEvent = function (event) {
    var el = getActualElement(event.srcElement);
    if (el == null || ignoreEvent(event, el)) return;
    el = getElement(el);
    if (el.id == "variableName" || el.id == "closeVariableModal" || el.id == "submitVariable") return;
    var action = {
        type: getEventType(event, el),
        actionType: getEventType(event, el),
        actionElementType: el.type,
        elementId: el.id,
        elementName: el.name,
        value: el.value,
        element: el,
        boltTestSequence: el.boltPageModel,
        pageModel: el.boltPageModel,
        elementModel: el.xpath,
        processed: false
    };

    if (localStorage.getItem("recording") != null && localStorage.getItem("recording") == "true" && action.element != null) {
        actions.push(action);
        actions = processActions(actions);
        localStorage.setItem("actions", JSON.stringify(actions));
    }
    if (localStorage.getItem("saveData") != null) {
        var savedData = localStorage.getItem("saveData");
        var actionSetter = localStorage.getItem('actions');
        actionSetter = actionSetter.substring(0, actionSetter.length - 1);
        actionSetter = actionSetter + savedData + ']';
        localStorage.setItem('actions', actionSetter);
    }

}

const getEventType = function (event, element) {
    if (event.type == "click" && element.tag != null && (element.tag.toLowerCase() == "mat-option" || element.tag.toLowerCase() == "option")) return "change";
    else if ((event.srcElement.tagName.toLowerCase() == "div" || event.srcElement.tagName.toLowerCase() == "button") && element.tag.toLowerCase() == "button" && event.type == "mouseup") return "click";
    else return event.type;
}

const ignoreEvent = function (event, element) {
    if (event.type == "mouseup" && event.srcElement.tagName.toLowerCase() != "div" && element.tagName.toLowerCase() != "button") {
        return true;
    }
    if (event.type == 'click' && element.type == "radio") {
        return true;
    }
    if (event.type == 'click' && element.tagName.toLowerCase() == "select") {
        return true;
    }
    return false;
}


const getActualElement = function (e) {
    if (elementsPath.indexOf(getPathTo(e)) > -1) {
        return e;
    }
    else if (e.parentElement != null && e.parentElement.tagName.toLowerCase() != "body") return getActualElement(e.parentElement);
    else return null;
}


const sendData = function () {
    var variableElements = localStorage.getItem("variableElement");
    if (variableElements != null) {
        var elementsArr = localStorage.getItem("elements");
        elementsArr = elementsArr.substring(0, elementsArr.length - 1)
        elementsArr = elementsArr + "," + variableElements + "]";
        console.log(elements);
        localStorage.setItem("elements", elementsArr);
    }
    var request = {
        url: localStorage.getItem("url"),
        projectId: localStorage.getItem("projectId"),
        workFlowName: localStorage.getItem("workFlowName"),
        elements: JSON.parse(localStorage.getItem("elements")),
        actions: JSON.parse(localStorage.getItem("actions"))
    };
    if (localStorage.getItem("insertInMiddle") != null && localStorage.getItem("insertInMiddle") == "true") {
        request.insertInMiddle = true;
        request.boltTestFlow = localStorage.getItem("boltTestFlow");
        request.boltTestSequence = localStorage.getItem("boltTestSequence");
        request.boltTestAction = localStorage.getItem("boltTestAction");
        request.eraseFromInsertionPoint = JSON.parse(localStorage.getItem("eraseFromInsertionPoint"));
    }
    var success = function () {
        console.log("Success");
    }
    var error = function () {
        console.log("Error");
    }
    if (localStorage.getItem("recording") != null && localStorage.getItem("recording") == "true" && request.actions != null && request.actions.size != 0) {
        post("https://localhost:8000/api/boltPageModelImport", request, success, error);
        //downloadPayload(request);
    }

}

const processActions = function (actions) {
    for (var index in actions) {
        if (!actions[index].processed) {
            actions[index].processed = true;
            if (actions[index].element.tag.toLowerCase() == "select") {
                actions[index].element.value = getOptionTextForSelect(actions[index]);
                actions[index].value = actions[index].element.value;
            }
            if (["mat-option", "option"].indexOf(actions[index].element.tag.toLowerCase()) > -1 && index - 1 >= 0 && ["mat-select", "select"].indexOf(actions[index - 1].element.tag.toLowerCase()) > -1) {
                actions[index - 1].element.value = actions[index].value;
                actions[index - 1].value = actions[index].value;
                actions[index - 1].type = "change";
                actions[index - 1].actionType = "change";
                actions.splice(index, 1);
            }
        }
    }
    return actions;
}

const getOptionTextForSelect = function (action) {
    var optionText = "";

    var selects = document.getElementsByTagName(action.element.tag);
    Object.keys(selects).forEach(key => {
        if (selects[key].id == action.element.id || selects[key].name == action.element.name) {
            Array.prototype.forEach.call(selects[key].selectedOptions, option => {
                optionText = option.value;
                console.log(option.value);
            });
            /*     selects[key].selectedOptions.forEach(option=>{
                    optionText = option.innerText;
    //                if(option.value==action.value){
    //                    optionText=option.innerText;
    //                }
                }); */
        }
    });
    return optionText;
}

const downloadPayload = function (payload) {
    let a = document.createElement('a');
    a.href = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(payload));
    a.download = "payload.json"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
}

const post = function (url, request, success, error) {
    $.ajax({
        type: "PUT",
        url: url,
        data: '{"changes":' + JSON.stringify(request) + '}',
        success: success,
        contentType: "application/json",
        error: error
    });
};

const syncChromeAndLocalStorage = function () {
    chrome.storage.local.get(['projectId', 'workFlowName', 'recording', 'insertInMiddle', 'boltTestFlow', 'boltTestSequence', 'boltTestAction', 'eraseFromInsertionPoint', 'pagaNameIdOption', 'pageNameIDRegex', 'pageNameIDXPath', 'pageNameQueryParam', 'pageVerification', 'elementsToVerify'], function (data) {

        localStorage.setItem("pageVerification", data.pageVerification);
        localStorage.setItem("projectId", data.projectId);
        localStorage.setItem("workFlowName", data.workFlowName);
        localStorage.setItem("pagaNameIdOption", data.pagaNameIdOption);
        localStorage.setItem("pageNameIDRegex", data.pageNameIDRegex);
        localStorage.setItem("pageNameIDXPath", data.pageNameIDXPath);
        localStorage.setItem("pageNameQueryParam", data.pageNameQueryParam);
        localStorage.setItem("elementsToVerify", data.elementsToVerify);
        if (data.insertInMiddle) {
            localStorage.setItem("insertInMiddle", data.insertInMiddle);
            localStorage.setItem("boltTestFlow", data.boltTestFlow);
            localStorage.setItem("boltTestSequence", data.boltTestSequence);
            localStorage.setItem("boltTestAction", data.boltTestAction);
            localStorage.setItem("eraseFromInsertionPoint", data.eraseFromInsertionPoint);
        }
        if (localStorage.getItem("recording") == "true" && !data.recording) sendData();
        localStorage.setItem("recording", data.recording);
        //  if(!data.pageVerification)
        onLoad();
        toggleRecorderPopup(data);
        if (!data.recording) clearLocalStorage();
    });
}

chrome.storage.onChanged.addListener(function (changes) {
    syncChromeAndLocalStorage();
});
const listenURLChange = function (url) {
    pageSequenceGenerator();
}

const pageSequenceGenerator = function () {
    let urlArray = localStorage.getItem('urls');
    let currentURL = document.URL;
    if (urlArray == null) {
        urlArray = currentURL + ",";
        let counter = 1;
        localStorage.setItem('urls', urlArray);
        localStorage.setItem('counter', counter);
    }
    if (urlArray.includes(currentURL)) return;
    else {
        urlArray = urlArray + currentURL + ",";
        localStorage.setItem('urls', urlArray);

        let counter = localStorage.getItem('counter');

        if (counter == null)
            counter = 1;

        if (counter != null) {
            counter = parseInt(counter);
            localStorage.setItem('counter', ++counter);
        }
    }
}

loadRecorderPopup = function (html) {
    var div = document.createElement("div");
    div.style["z-index"] = 1000;
    div.style.position = "fixed"
    div.style.top = "0px";
    div.style.right = "250px";
    div.innerHTML = html;
    document.body.appendChild(div);
    dragElement(document.getElementById("superbolt-recorder"));
}
toggleRecorderPopup = function (data) {
    if ($("#superbolt-project-id")[0] != null) $("#superbolt-project-id")[0].innerText = data.projectId;
    if (data.recording) $("#superbolt-recorder").show();
    else if (data.pageVerification) $("#superbolt-recorder").show();
    else $("#superbolt-recorder").hide();
}

clearLocalStorage = function () {
    localStorage.removeItem("projectId");
    localStorage.removeItem("counter");
    localStorage.removeItem("urls");
    localStorage.removeItem("variableElement");
    localStorage.removeItem("saveData");
    localStorage.removeItem("workFlowName");
    localStorage.removeItem("pagaNameIdOption");
    localStorage.removeItem("pageNameIDRegex");
    localStorage.removeItem("pageNameIDXPath");
    localStorage.removeItem("pageNameQueryParam");
    localStorage.removeItem("elements");
    localStorage.removeItem("actions");
    localStorage.removeItem("insertInMiddle");
    localStorage.removeItem("boltTestFlow");
    localStorage.removeItem("boltTestSequence");
    localStorage.removeItem("boltTestAction");
    localStorage.removeItem("eraseFromInsertionPoint");
}

$.get(chrome.runtime.getURL("plugin/html/rec-popup.html"), loadRecorderPopup);
//syncChromeAndLocalStorage();
window.onbeforeunload = sendData;